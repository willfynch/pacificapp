# Pacificapp



## Launch the app 

To launch the app :

Open a terminal in ./pacificapp 

Run 'npm install' 

Then : 'npm run start'



## Testing

Unit Tests are implemented with Jest

Run 'npm run test'
